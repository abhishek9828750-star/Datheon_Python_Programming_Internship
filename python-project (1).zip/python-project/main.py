
import random

words = ["python", "computer", "coding", "college"]
word = random.choice(words)
guessed = []
attempts = 6

print("WELCOME TO HANGMAN GAME!")

while attempts > 0:
    display = ""

    for letter in word:
        if letter in guessed:
            display += letter + " "
        else:
            display += "_ "

    print("\nWord:", display)
    print("Attempts left:", attempts)

    if all(letter in guessed for letter in word):
        print("You Win! Congratulations!")
        break

    guess = input("Guess a letter: ").lower().strip()

    if len(guess) != 1 or not guess.isalpha():
        print("Enter only one letter.")
        continue

    if guess in guessed:
        print("You already guessed it!")
        continue

    guessed.append(guess)

    if guess in word:
        print("Correct!")
    else:
        print("Wrong!")
        attempts -= 1

if attempts == 0:
    print("\nGame Over!")
    print("The word was:", word)
