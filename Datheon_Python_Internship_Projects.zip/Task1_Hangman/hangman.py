import random

WORDS = ["python", "computer", "student", "internet", "programming",
         "keyboard", "college", "science", "project", "function"]

def play_hangman():
    secret_word = random.choice(WORDS)
    guessed_letters = set()
    wrong_guesses = 0
    max_wrong = 6

    print("\n=== HANGMAN WORD GUESSING GAME ===")
    print("Guess the word one letter at a time.")
    print(f"You can make {max_wrong} wrong guesses.")

    while wrong_guesses < max_wrong:
        display = " ".join(letter if letter in guessed_letters else "_" for letter in secret_word)
        print("\nWord:", display)
        print("Wrong guesses:", wrong_guesses, "/", max_wrong)

        if all(letter in guessed_letters for letter in secret_word):
            print("Congratulations! You guessed the word:", secret_word)
            return

        guess = input("Enter one letter: ").strip().lower()
        if len(guess) != 1 or not guess.isalpha():
            print("Please enter only one alphabet letter.")
            continue
        if guess in guessed_letters:
            print("You already tried that letter. Try another.")
            continue

        guessed_letters.add(guess)
        if guess in secret_word:
            print("Correct!")
        else:
            wrong_guesses += 1
            print("Sorry, that letter is not in the word.")

    print("\nGame over! The word was:", secret_word)

if __name__ == "__main__":
    while True:
        play_hangman()
        if input("\nPlay again? (y/n): ").strip().lower() != "y":
            print("Thanks for playing!")
            break
