import csv
import os
from datetime import datetime

CSV_FILE = "portfolio_log.csv"

def get_positive_number(prompt):
    while True:
        try:
            value = float(input(prompt))
            if value < 0:
                print("Please enter zero or a positive number.")
                continue
            return value
        except ValueError:
            print("Please enter a valid number, for example 125.50.")

def main():
    print("\n=== STOCK PORTFOLIO PERFORMANCE TRACKER ===")
    print("Note: Enter prices yourself. This beginner project does not fetch live market prices.")
    stock_name = input("Stock/company name or symbol: ").strip()
    if not stock_name:
        stock_name = "Unknown"
    quantity = get_positive_number("Number of shares: ")
    buy_price = get_positive_number("Purchase price per share (₹): ")
    current_price = get_positive_number("Current price per share (₹): ")

    invested = quantity * buy_price
    current_value = quantity * current_price
    profit_loss = current_value - invested
    percent = (profit_loss / invested * 100) if invested else 0

    print("\n--- Portfolio Summary ---")
    print(f"Stock: {stock_name}")
    print(f"Amount invested: ₹{invested:.2f}")
    print(f"Current portfolio value: ₹{current_value:.2f}")
    print(f"Profit/Loss: ₹{profit_loss:.2f}")
    print(f"Return: {percent:.2f}%")

    file_exists = os.path.exists(CSV_FILE)
    with open(CSV_FILE, "a", newline="", encoding="utf-8") as file:
        writer = csv.writer(file)
        if not file_exists:
            writer.writerow(["date_time", "stock", "quantity", "buy_price",
                             "current_price", "invested", "current_value",
                             "profit_loss", "return_percent"])
        writer.writerow([datetime.now().isoformat(timespec="seconds"), stock_name,
                         quantity, buy_price, current_price, invested,
                         current_value, profit_loss, percent])
    print(f"\nRecord saved to {CSV_FILE}")

if __name__ == "__main__":
    main()
