from datetime import datetime

def get_reply(message):
    text = message.lower().strip()

    if any(word in text for word in ["hello", "hi", "hey"]):
        return "Hello! How can I help you?"
    if "your name" in text or "who are you" in text:
        return "I am a simple rule-based chatbot made with Python."
    if "time" in text:
        return "The current time is " + datetime.now().strftime("%I:%M %p") + "."
    if "date" in text or "today" in text:
        return "Today's date is " + datetime.now().strftime("%d-%m-%Y") + "."
    if "python" in text:
        return "Python is a beginner-friendly programming language."
    if "thank" in text:
        return "You're welcome!"
    if any(word in text for word in ["bye", "exit", "quit"]):
        return "Goodbye! Have a nice day."
    return "Sorry, I don't know that yet. Try asking about my name, time, date, or Python."

def main():
    print("=== RULE-BASED TERMINAL CHATBOT ===")
    print("Type 'bye' to end the chat.")
    while True:
        message = input("\nYou: ")
        reply = get_reply(message)
        print("Bot:", reply)
        if any(word in message.lower().strip() for word in ["bye", "exit", "quit"]):
            break

if __name__ == "__main__":
    main()
