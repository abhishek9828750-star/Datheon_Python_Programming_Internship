from pathlib import Path
import shutil

CATEGORIES = {
    "Images": {".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp"},
    "Documents": {".pdf", ".doc", ".docx", ".txt", ".ppt", ".pptx", ".xls", ".xlsx"},
    "Audio": {".mp3", ".wav", ".aac", ".m4a"},
    "Videos": {".mp4", ".mkv", ".mov", ".avi"},
    "Archives": {".zip", ".rar", ".7z", ".tar", ".gz"},
    "Code": {".py", ".c", ".cpp", ".java", ".html", ".css", ".js"}
}

def category_for(file_path):
    for category, extensions in CATEGORIES.items():
        if file_path.suffix.lower() in extensions:
            return category
    return "Others"

def main():
    print("\n=== AUTOMATED FILE ORGANIZER ===")
    print("This tool moves files in the folder you choose into category folders.")
    raw_path = input("Enter the full path of the folder to organize: ").strip().strip('"')
    folder = Path(raw_path).expanduser()

    if not folder.exists() or not folder.is_dir():
        print("Folder not found. Please check the path and try again.")
        return

    confirm = input(f"Organize files inside '{folder}'? (yes/no): ").strip().lower()
    if confirm != "yes":
        print("Cancelled. No files were moved.")
        return

    moved = 0
    for item in list(folder.iterdir()):
        if not item.is_file() or item.name == Path(__file__).name:
            continue
        category = category_for(item)
        destination_folder = folder / category
        destination_folder.mkdir(exist_ok=True)
        destination = destination_folder / item.name

        # Avoid overwriting a file with the same name.
        if destination.exists():
            stem, suffix, number = item.stem, item.suffix, 1
            while (destination_folder / f"{stem}_{number}{suffix}").exists():
                number += 1
            destination = destination_folder / f"{stem}_{number}{suffix}"

        shutil.move(str(item), str(destination))
        print(f"Moved: {item.name} -> {category}/{destination.name}")
        moved += 1

    print(f"\nFinished. Files moved: {moved}")

if __name__ == "__main__":
    main()
