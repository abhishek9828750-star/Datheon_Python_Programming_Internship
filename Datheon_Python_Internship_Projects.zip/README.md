# Datheon Python Programming Internship Projects

This repository contains four beginner-friendly Python console projects.

## Project list
1. **Hangman Word Guessing Game** — random words, letter guesses, input validation, and replay.
2. **Stock Portfolio Performance Tracker** — calculates invested value, current value, profit/loss, percentage return, and saves records to CSV. Prices are entered by the user; this version does not fetch live market data.
3. **Automated File Organizer & Cleanup Utility** — sorts files by extension into folders. It asks for confirmation before moving files. Test it on a sample folder first.
4. **Rule-Based Interactive Terminal Assistant / Chatbot** — responds to simple words and questions using rules.

## How to run
You need Python 3 installed on a computer or a Python-running app/site.

Open a terminal in the relevant project folder and run:

```bash
python hangman.py
python stock_tracker.py
python file_organizer.py
python chatbot.py
```

Use the matching filename from its own task folder. For example, run `python hangman.py` from `Task1_Hangman`.

## Android beginner option
If Python is not installed on your Android phone, use a reputable online Python editor that lets you type and run Python code. Open the `.py` file, copy its code into the editor, and press Run. Do not enter private information into an online editor.

## GitHub submission
1. Create a GitHub account or sign in.
2. Create a **public** repository named `Datheon_Python_Programming_Internship`.
3. Upload all four task folders and this `README.md`.
4. Copy the repository URL and paste it into Datheon's submission form.
5. Check the internship's own task pack and submission instructions before submitting.

## Important notes
- Test each project before submitting.
- The file organizer moves files. Test only with a temporary sample folder containing copies of files.
- The stock tracker is a learning demo, not financial advice and not a live stock-price service.
- Understand the code well enough to explain it; edit the README with your own learning notes if needed.
